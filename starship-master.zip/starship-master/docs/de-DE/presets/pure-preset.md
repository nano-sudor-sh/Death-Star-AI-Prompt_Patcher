[Zurück zu den Voreinstellungen](./#pure)

# Pure Voreinstellung

Diese Voreinstellung emuliert das Aussehen und das Verhalten von [Pure](https://github.com/sindresorhus/pure).

![Screenshot der Pure Voreinstellung](/presets/img/pure-preset.png)

### Konfiguration

```sh
starship preset pure-preset -o ~/.config/starship.toml
```

[Zum Herunterladen der TOML Datei klicken](/presets/toml/pure-preset.toml)

<<< @/public/presets/toml/pure-preset.toml
