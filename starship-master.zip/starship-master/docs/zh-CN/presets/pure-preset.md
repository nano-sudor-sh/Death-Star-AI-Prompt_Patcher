[返回全部预设](./#pure)

# Pure Preset

此预设模拟 [Pure](https://github.com/sindresorhus/pure) 的外观和行为。

![Pure 预设屏幕截图](/presets/img/pure-preset.png)

### 配置

```sh
starship preset pure-preset -o ~/.config/starship.toml
```

[点击下载 TOML 文件](/presets/toml/pure-preset.toml)

<<< @/public/presets/toml/pure-preset.toml
