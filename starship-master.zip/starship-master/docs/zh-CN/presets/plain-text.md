[返回全部预设](./#plain-text-symbols)

## Plain Text Symbols Preset

此预设将所有组件的符号改为纯文本。 适合没有 Unicode 的环境。

![Screenshot of Plain Text Symbols preset](/presets/img/plain-text-symbols.png)

### 配置

```sh
starship preset plain-text-symbols -o ~/.config/starship.toml
```

[点击下载 TOML 文件](/presets/toml/plain-text-symbols.toml)

<<< @/public/presets/toml/plain-text-symbols.toml
