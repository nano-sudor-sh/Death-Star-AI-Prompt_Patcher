[プリセット一覧に戻る](./#plain-text-symbols)

## Plain Text Symbolsプリセット

このプリセットはそれぞれのモジュールで記号をテキストに変更します。 Unicodeにアクセスできない場合に最適です。

![Plain Text Symbolsプリセットのスクリーンショット](/presets/img/plain-text-symbols.png)

### 設定

```sh
starship preset plain-text-symbols -o ~/.config/starship.toml
```

[クリックしてTOMLをダウンロード](/presets/toml/plain-text-symbols.toml)

<<< @/public/presets/toml/plain-text-symbols.toml
