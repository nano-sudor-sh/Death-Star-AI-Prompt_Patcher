[プリセット一覧に戻る](./#pure)

# Pureプリセット

このプリセットは、[Pure](https://github.com/sindresorhus/pure)の外観と振る舞いをエミュレートします。

![Pureプリセットのスクリーンショット](/presets/img/pure-preset.png)

### 設定

```sh
starship preset pure-preset -o ~/.config/starship.toml
```

[クリックしてTOMLをダウンロード](/presets/toml/pure-preset.toml)

<<< @/public/presets/toml/pure-preset.toml
