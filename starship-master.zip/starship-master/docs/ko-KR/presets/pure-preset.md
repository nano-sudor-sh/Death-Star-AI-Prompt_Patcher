[프리셋으로 돌아가기](./#pure)

# Pure 프리셋

이 프리셋은 [Pure](https://github.com/sindresorhus/pure)의 모습과 동작을 재현합니다.

![Pure 프리셋 스크린샷](/presets/img/pure-preset.png)

### 설정

```sh
starship preset pure-preset -o ~/.config/starship.toml
```

[클릭하여 TOML 다운로드](/presets/toml/pure-preset.toml)

<<< @/public/presets/toml/pure-preset.toml
