[Powrót do ustawień predefiniowanych](./#pure)

# Ustawienia Pure

Ten zestaw ustawień naśladuje wygląd i zachowanie  [Pure](https://github.com/sindresorhus/pure).

![Zrzut ekranu ustawień Pure](/presets/img/pure-preset.png)

### Konfiguracja

```sh
starship preset pure-preset -o ~/.config/starship.toml
```

[Kliknij, aby pobrać TOML](/presets/toml/pure-preset.toml)

<<< @/public/presets/toml/pure-preset.toml
