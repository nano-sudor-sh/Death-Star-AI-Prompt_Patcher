[Retourner aux préréglages](./#plain-text-symbols)

## Préréglage Symboles en texte brut

Ce préréglage change les symboles de chaque module en texte brut. Idéal si vous n'avez pas accès à Unicode.

![Capture d'écran du préréglage Texte uniquement](/presets/img/plain-text-symbols.png)

### Configuration

```sh
starship preset plain-text-symbols -o ~/.config/starship.toml
```

[Cliquez pour télécharger le TOML](/presets/toml/plain-text-symbols.toml)

<<< @/public/presets/toml/plain-text-symbols.toml
