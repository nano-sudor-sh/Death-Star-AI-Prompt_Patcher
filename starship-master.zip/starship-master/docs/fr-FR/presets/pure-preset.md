[Retourner aux préréglages](./#pure)

# Préréglage Pure

Ce préréglage émule l'apparence et le comportement de [Pure](https://github.com/sindresorhus/pure).

![Capture d'écran du préréglage Pure](/presets/img/pure-preset.png)

### Configuration

```sh
starship preset pure-preset -o ~/.config/starship.toml
```

[Cliquez pour télécharger le TOML](/presets/toml/pure-preset.toml)

<<< @/public/presets/toml/pure-preset.toml
