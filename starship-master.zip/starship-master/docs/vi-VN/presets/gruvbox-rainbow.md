[Return to Presets](./#gruvbox-rainbow)

# Gruvbox Rainbow Preset

This preset is heavily inspired by [Pastel Powerline](./pastel-powerline.md), and [Tokyo Night](./tokyo-night.md).

![Screenshot of Gruvbox Rainbow preset](/presets/img/gruvbox-rainbow.png)

### Yêu cầu

- Đã cài đặt một [Nerd Font](https://www.nerdfonts.com/) và kích hoạt trong terminal của bạn

### Cấu hình

```sh
starship preset gruvbox-rainbow -o ~/.config/starship.toml
```

[Nhấn vào đây để tải tệp tin TOML](/presets/toml/gruvbox-rainbow.toml)

<<< @/public/presets/toml/gruvbox-rainbow.toml
