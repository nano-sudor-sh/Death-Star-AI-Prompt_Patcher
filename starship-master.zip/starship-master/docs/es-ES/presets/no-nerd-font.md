[Volver a Preajustes](./#no-nerd-fonts)

# No Nerd Fonts Preset

This preset restricts the use of symbols to those from emoji and powerline sets.

Esto significa que incluso sin una fuente Nerd instalada, debería ser capaz de ver todos los símbolos del módulo.

Este preset será el predeterminado en una futura versión de starship.

### Configuración

```sh
starship preset no-nerd-font -o ~/.config/starship.toml
```

[Clic para descargar TOML](/presets/toml/no-nerd-font.toml)

<<< @/public/presets/toml/no-nerd-font.toml
