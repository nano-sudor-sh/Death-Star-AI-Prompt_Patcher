[Volver a Preajustes](./#pure)

# Preajuste Pure

Esta preajuste emula la apariencia y el comportamiento de [Pure](https://github.com/sindresorhus/pure).

![Captura de pantalla del ajuste de Pure](/presets/img/pure-preset.png)

### Configuración

```sh
starship preset pure-preset -o ~/.config/starship.toml
```

[Clic para descargar TOML](/presets/toml/pure-preset.toml)

<<< @/public/presets/toml/pure-preset.toml
