[Volver a Preajustes](./#plain-text-symbols)

## Preajuste Símbolos de Texto sin Formato

Este preajuste cambia los símbolos a texto sin formato. Bueno si usted no tiene acceso a Unicode.

![Captura de pantalla del ajuste de los Símbolos de Texto Plano](/presets/img/plain-text-symbols.png)

### Configuración

```sh
starship preset plain-text-symbols -o ~/.config/starship.toml
```

[Clic para descargar TOML](/presets/toml/plain-text-symbols.toml)

<<< @/public/presets/toml/plain-text-symbols.toml
