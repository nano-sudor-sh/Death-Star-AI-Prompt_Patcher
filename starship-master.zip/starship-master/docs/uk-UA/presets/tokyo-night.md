[Повернутися до Шаблонів](./#pastel-powerline)

# Tokyo Night

Цей шаблон створений під враженням від [tokyo-night-vscode-theme](https://github.com/enkia/tokyo-night-vscode-theme).

![Скріншот шаблону Tokyo Night](/presets/img/tokyo-night.png)

### Передумови

- Встановлений та увімкнений шрифт [Nerd Font](https://www.nerdfonts.com/) у вашому терміналі

### Налаштування

```sh
starship preset tokyo-night -o ~/.config/starship.toml
```

[Натисніть, щоб завантажити TOML](/presets/toml/tokyo-night.toml)

<<< @/public/presets/toml/tokyo-night.toml
