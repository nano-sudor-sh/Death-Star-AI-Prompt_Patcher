[Повернутися до Шаблонів](./#plain-text-symbols)

## Plain Text Symbols

Цей шаблон замінює символи в кожному модулі звичайним текстом. Це ваш вибір, якщо у вас немає доступу до символів Unicode.

![Скріншот шаблона Plain Text Symbols](/presets/img/plain-text-symbols.png)

### Налаштування

```sh
starship preset plain-text-symbols -o ~/.config/starship.toml
```

[Натисніть, щоб завантажити TOML](/presets/toml/plain-text-symbols.toml)

<<< @/public/presets/toml/plain-text-symbols.toml
