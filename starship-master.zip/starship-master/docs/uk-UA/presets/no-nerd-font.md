[Повернутися до Шаблонів](./#no-nerd-fonts)

# No Nerd Fonts

Шаблон обмежує використання символів символами емодзі та powerline.

Це означає, що навіть без встановленого шрифту Nerd Font, ви можете побачити всі символи модуля.

Цей шаблон стане стандартною схемою в наступному випуску starship.

### Налаштування

```sh
starship preset no-nerd-font -o ~/.config/starship.toml
```

[Натисніть, щоб завантажити TOML](/presets/toml/no-nerd-font.toml)

<<< @/public/presets/toml/no-nerd-font.toml
