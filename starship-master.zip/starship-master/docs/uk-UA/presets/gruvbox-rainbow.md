[Повернутися до Шаблонів](./#gruvbox-rainbow)

# Шаблон Gruvbox Rainbow

Цей шаблон створено під впливом [Pastel Powerline](./pastel-powerline.md) та [Tokyo Night](./tokyo-night.md).

![Скріншот шаблона Gruvbox Rainbow](/presets/img/gruvbox-rainbow.png)

### Передумови

- Встановлений та увімкнений шрифт [Nerd Font](https://www.nerdfonts.com/) у вашому терміналі

### Налаштування

```sh
starship preset gruvbox-rainbow -o ~/.config/starship.toml
```

[Натисніть, щоб завантажити TOML](/presets/toml/gruvbox-rainbow.toml)

<<< @/public/presets/toml/gruvbox-rainbow.toml
