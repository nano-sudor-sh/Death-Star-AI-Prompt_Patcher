[Повернутися до Шаблонів](./#pure)

# Pure Prompt

Цей шаблон імітує зовнішній вигляд і поведінку [Pure](https://github.com/sindresorhus/pure).

![Скріншот шаблона Pure Prompt](/presets/img/pure-preset.png)

### Налаштування

```sh
starship preset pure-preset -o ~/.config/starship.toml
```

[Натисніть, щоб завантажити TOML](/presets/toml/pure-preset.toml)

<<< @/public/presets/toml/pure-preset.toml
