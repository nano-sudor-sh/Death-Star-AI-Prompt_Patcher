[Return to Presets](./#pure)

# Pure Preset

ئەم پێش ڕێکخستنە لاسایی شێواز و ڕەفتاری [Pure](https://github.com/sindresorhus/pure) دەکاتەوە.

![Screenshot of Pure preset](/presets/img/pure-preset.png)

### ڕێکخستن

```sh
starship preset pure-preset -o ~/.config/starship.toml
```

[Click to download TOML](/presets/toml/pure-preset.toml)

<<< @/public/presets/toml/pure-preset.toml
