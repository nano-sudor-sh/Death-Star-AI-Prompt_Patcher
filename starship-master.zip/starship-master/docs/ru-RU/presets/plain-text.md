[Вернуться к пресетам](./#plain-text-symbols)

## Пресет Plain Text Symbols

Этот пресет изменяет символы для каждого модуля на обычный текст. Отлично подходит, если у вас нет возможности использовать Unicode.

![Скриншот пресета Plain Text Symbols](/presets/img/plain-text-symbols.png)

### Конфигурация

```sh
starship preset plain-text-symbols -o ~/.config/starship.toml
```

[Нажмите, чтобы загрузить TOML](/presets/toml/plain-text-symbols.toml)

<<< @/public/presets/toml/plain-text-symbols.toml
