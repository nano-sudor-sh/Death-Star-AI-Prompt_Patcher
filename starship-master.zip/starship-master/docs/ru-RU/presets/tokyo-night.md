[Вернуться к пресетам](./#pastel-powerline)

# Пресет Tokyo Night

Этот пресет вдохновлен [tokyo-night-vscode-theme](https://github.com/enkia/tokyo-night-vscode-theme).

![Скриншот пресета Tokyo Night](/presets/img/tokyo-night.png)

### Обязательные требования

- Установленный и включенный шрифт [Nerd Font](https://www.nerdfonts.com/) в вашем терминале

### Конфигурация

```sh
starship preset tokyo-night -o ~/.config/starship.toml
```

[Нажмите, чтобы загрузить TOML](/presets/toml/tokyo-night.toml)

<<< @/public/presets/toml/tokyo-night.toml
