[Вернуться к пресетам](./#pure)

# Пресет Pure

Этот пресет имитирует внешний вид и поведение [Pure](https://github.com/sindresorhus/pure).

![Скриншот пресета Pure](/presets/img/pure-preset.png)

### Конфигурация

```sh
starship preset pure-preset -o ~/.config/starship.toml
```

[Нажмите, чтобы загрузить TOML](/presets/toml/pure-preset.toml)

<<< @/public/presets/toml/pure-preset.toml
